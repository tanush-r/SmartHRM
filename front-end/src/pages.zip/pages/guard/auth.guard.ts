import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../../app/auth.service';
import { NgIf } from '@angular/common';

export const authGuard: CanActivateFn = (route, state) => {
  // return true;
  const AuthServices = inject(AuthService);
  const router= inject(Router);
  if(AuthServices.isAuthenticated()){
    return true;
  }else{
    return false
  }
    
}
