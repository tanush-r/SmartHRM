import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterOutlet } from '@angular/router';

interface Client {
  client_id: string;
  client_name: string;
}

interface Position {
  jd_id: string;
  client_id: string;
  filename: string;
  s3_link: string; // Ensure this is included
  timestamp: string;
}

interface Resume {
  resume_id: string; // Add resume_id
  jd_id: string; // Add jd_id
  filename: string;
  s3_link: string;
  timestamp: string;
  status: string;
  eligible: boolean;
  notEligible: boolean;
  onboarded: boolean;
}

@Component({
  selector: 'app-resumelist',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterLink, RouterOutlet],
  templateUrl: './resumelist.component.html',
  styleUrls: ['./resumelist.component.css']
})
export class ResumelistComponent implements OnInit {
  clients: Client[] = [];
  positions: Position[] = [];
  selectedClientId: string = '';
  selectedPosition: string = '';
  resumes: Resume[] = [];
  selectedPositionS3Link: string | null = null; // Store selected position's s3_link
  isLoadingResumes: boolean = false; // Loader state for fetching resumes

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.loadClients(); // Load clients as soon as the component is initialized
  }

  loadClients(): void {
    this.http.get<Client[]>('/api/viewer/clients').subscribe(
      (data: Client[]) => {
        this.clients = data; // Store the fetched clients
      },
      (error) => {
        console.error('Error fetching clients:', error);
      }
    );
  }

  onClientChange(): void {
    if (this.selectedClientId) {
      this.loadPositions(this.selectedClientId); // Load positions when a client is selected
    } else {
      this.positions = []; // Clear positions if no client is selected
    }
  }

  loadPositions(clientId: string): void {
    this.http.get<Position[]>(`/api/viewer/positions?client_id=${clientId}`).subscribe(
      (data: Position[]) => {
        this.positions = data; // Store the fetched positions
      },
      (error) => {
        console.error('Error fetching positions:', error);
        this.positions = []; // Clear positions on error
      }
    );
  }

  fetchResumes(): void {
    if (this.selectedClientId && this.selectedPosition) {
      this.isLoadingResumes = true; // Start loading
      this.http.get<Resume[]>(`/api/viewer/resumes?jd_id=${this.selectedPosition}`).subscribe(
        (data: Resume[]) => {
          this.resumes = data; // Store the fetched resumes
          this.isLoadingResumes = false; // Stop loading
        },
        (error) => {
          console.error('Error fetching resumes:', error);
          this.resumes = []; // Clear resumes on error
          this.isLoadingResumes = false; // Stop loading
        }
      );
    } else {
      alert('Please select a client and position.'); // Alert if selections are missing
    }
  }

  downloadResume(s3_link: string): void {
    if (s3_link) {
      window.open(s3_link, '_blank'); // Open the S3 link in a new tab
    } else {
      alert('No S3 link available for the selected resume.'); // Alert if no link
    }
  }

  viewResume(resume: Resume): void {
    if (resume.s3_link && this.selectedPositionS3Link) {
      this.router.navigate(['/questioner'], {
        queryParams: {
          resumeS3Link: resume.s3_link,
          positionS3Link: this.selectedPositionS3Link,
          resumeId: resume.resume_id, // Pass resume_id
          jdId: resume.jd_id // Pass jd_id
        }
      }); // Navigate to questioner component with parameters
    } else {
      alert('No S3 link available for the selected resume or position.'); // Alert if links are missing
    }
  }

  onPositionSelect(): void {
    const selectedPosition = this.positions.find(pos => pos.jd_id === this.selectedPosition);
    if (selectedPosition) {
      this.selectedPositionS3Link = selectedPosition.s3_link; // Store the selected position's s3_link
    }
  }

  formatDate(timestamp: string): string {
    const date = new Date(timestamp);
    return date.toLocaleDateString(); // Format date to local string
  }

  formatTime(timestamp: string): string {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); // Format time to local string
  }
}
