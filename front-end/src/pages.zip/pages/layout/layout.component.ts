import { Component, OnInit } from '@angular/core';
import { RouterLinkActive, RouterLink, RouterOutlet } from '@angular/router';
import { Firestore, doc, getDoc } from '@angular/fire/firestore'; // Firestore methods
import { Auth, signOut } from '@angular/fire/auth'; // Firebase Auth methods
import { inject } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [RouterLink, RouterOutlet, RouterLinkActive],
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {
  username: string | null = null; // Store the fetched username
  firestore = inject(Firestore); // Inject Firestore
  firebaseAuth = inject(Auth); // Inject Firebase Auth
  private router = inject(Router); // Inject Router

  options = [
    { value: 'profile', label: 'Profile' },
    { value: 'logout', label: 'Logout' }
  ]; // Dropdown options for profile and logout

  ngOnInit(): void {
    this.loadUsername(); // Load username from local storage
    this.fetchUserData(); // Fetch the user data from Firestore
  }

  // Method to load username from local storage
  private loadUsername(): void {
    const storedUsername = localStorage.getItem('username');
    if (storedUsername) {
      this.username = storedUsername; // Set username from local storage if available
    }
  }

  // Method to fetch the username from Firestore
  private async fetchUserData(): Promise<void> {
    const user = this.firebaseAuth.currentUser; // Get the currently logged-in user
    if (user) {
      try {
        const userDocRef = doc(this.firestore, 'users', user.uid); // Reference to the user's document in Firestore
        const userDoc = await getDoc(userDocRef); // Fetch the document
        if (userDoc.exists()) {
          this.username = userDoc.data()?.['username'] || null; // Get the 'username' field if it exists
          // Store username in local storage only if it's not null
          if (this.username) {
            localStorage.setItem('username', this.username); // Store username in local storage
          }
        } else {
          console.error('No such document!');
        }
      } catch (error) {
        console.error('Error fetching user document:', error);
      }
    } else {
      console.log('No user is currently signed in.');
    }
  }

  // Method to log out the user
  async logout(): Promise<void> {
    try {
      await signOut(this.firebaseAuth); // Log out the user
      localStorage.removeItem('user'); // Remove username from local storage
      this.router.navigate(['/login'], { replaceUrl: true }); // Navigate to login page after logout, replace URL to clear navigation history
    } catch (error) {
      console.error('Error signing out:', error);
    }
  }
}
