import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Auth } from '@angular/fire/auth';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { Firestore, doc, setDoc, getDoc } from '@angular/fire/firestore';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [ReactiveFormsModule, RouterModule,CommonModule],
})
export class LoginComponent implements OnInit, OnDestroy {
  fb = inject(FormBuilder);
  http = inject(HttpClient);
  router = inject(Router);
  firebaseAuth = inject(Auth);
  firestore = inject(Firestore);

  // Create a reactive form with email and password fields
  form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]], // Email field
    password: ['', Validators.required], // Password field
  });

  errorMessage: string | null = null; // For storing error messages
  isLoading: boolean = false; // For showing loading state
  inactivityTimeout: any = null; // Timeout reference for inactivity logout
  activityEvents = ['mousemove', 'keydown']; // Events that extend the session

  ngOnInit() {
    // Add event listeners for user activity
    this.activityEvents.forEach((event) => {
      window.addEventListener(event, this.resetInactivityTimeout.bind(this));
    });
    this.startInactivityTimeout(); // Start the inactivity timeout
  }

  ngOnDestroy() {
    // Remove event listeners when the component is destroyed
    this.activityEvents.forEach((event) => {
      window.removeEventListener(event, this.resetInactivityTimeout.bind(this));
    });
    clearTimeout(this.inactivityTimeout); // Clear timeout on component destroy
  }

  // Method to start or reset the inactivity timeout
  startInactivityTimeout() {
    clearTimeout(this.inactivityTimeout); // Clear any existing timeout

    // Set the inactivity timeout to log out after 1 minute (60000 ms)
    this.inactivityTimeout = setTimeout(() => {
      this.logout(); // Auto-logout on inactivity
    }, 60000); // 1 minute timeout
  }

  // Method to reset the inactivity timeout when user interacts
  resetInactivityTimeout() {
    this.startInactivityTimeout();
  }

  // Log the user out and clear the session
  logout() {
    localStorage.removeItem('user'); // Clear user data from localStorage
    localStorage.removeItem('loginTimestamp'); // Clear login timestamp
    this.router.navigate(['login']); // Navigate to the login page
    console.log('Logged out due to inactivity.');
  }

  async onSubmit(): Promise<void> {
    const { email, password } = this.form.value;

    if (email && password) {
      this.isLoading = true; // Set loading to true

      try {
        // Sign in with Firebase Authentication
        const userCredential = await signInWithEmailAndPassword(
          this.firebaseAuth,
          email,
          password
        );
        const user = userCredential.user;

        // Reference to Firestore document for the user
        const userDocRef = doc(this.firestore, 'users', user.uid);

        const loginTimestamp = new Date(); // Current date and time

        // Store user info in Firestore
        await setDoc(
          userDocRef,
          {
            email: user.email,
            lastLogin: loginTimestamp.toISOString(), // Store last login time in ISO format
          },
          { merge: true }
        );

        // Fetch user info (including username) from Firestore
        const userDoc = await getDoc(userDocRef);
        let username: string | null = null;

        if (userDoc.exists()) {
          username = userDoc.data()?.['username'] || null; // Get username from Firestore
        } else {
          console.error('No such document!');
        }

        // Store user info in local storage for session management
        localStorage.setItem(
          'user',
          JSON.stringify({ email: user.email, uid: user.uid, username })
        );
        localStorage.setItem('loginTimestamp', loginTimestamp.toISOString());

        // Navigate to the home page
        this.router.navigate(['/home']);
      } catch (error) {
        this.isLoading = false; // Reset loading on error
        this.errorMessage = (error as Error).message; // Set error message
        console.error('Error signing in:', error);
      } finally {
        this.isLoading = false; // Reset loading regardless of success or error
      }
    } else {
      this.errorMessage = 'All fields are required.'; // Check if all fields are filled
    }
  }
}